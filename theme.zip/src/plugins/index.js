// Automatically included in './src/main.js'

import './base'
import './meta'
import './webfontloader'
